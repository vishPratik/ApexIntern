document.addEventListener("DOMContentLoaded", loadTasks);

function addTask() {
    const taskInput = document.getElementById("taskInput");
    const priority = document.getElementById("priority").value;
    const taskList = document.getElementById("taskList");

    if (taskInput.value.trim() === "") {
        alert("Task cannot be empty!");
        return;
    }

    const li = document.createElement("li");
    li.classList.add(priority);
    li.innerHTML = `
        ${taskInput.value}
        <button class="delete-btn" onclick="removeTask(this)">❌</button>
    `;

    taskList.appendChild(li);
    saveTasks();

    taskInput.value = ""; // Clear input after adding task
}

function removeTask(button) {
    button.parentElement.remove();
    saveTasks();
}

function saveTasks() {
    const tasks = [];
    document.querySelectorAll("#taskList li").forEach(li => {
        tasks.push({ text: li.textContent.replace("❌", "").trim(), priority: li.classList[0] });
    });
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasks() {
    const taskList = document.getElementById("taskList");
    const tasks = JSON.parse(localStorage.getItem("tasks")) || [];

    tasks.forEach(task => {
        const li = document.createElement("li");
        li.classList.add(task.priority);
        li.innerHTML = `
            ${task.text}
            <button class="delete-btn" onclick="removeTask(this)">❌</button>
        `;
        taskList.appendChild(li);
    });
}
