document.getElementById("contactForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent page refresh

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const message = document.getElementById("message").value.trim();
    const formMessage = document.getElementById("formMessage");

    if (name === "" || email === "" || message === "") {
        formMessage.style.color = "red";
        formMessage.textContent = "⚠️ All fields are required!";
        return;
    }

    if (!email.includes("@") || !email.includes(".")) {
        formMessage.style.color = "red";
        formMessage.textContent = "⚠️ Enter a valid email address!";
        return;
    }

    formMessage.style.color = "green";
    formMessage.textContent = "✅ Message sent successfully!";
    
    document.getElementById("contactForm").reset();
});
