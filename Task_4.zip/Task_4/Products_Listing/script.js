const products = [
    { id: 1, name: 'Laptop', category: 'electronics', price: 999.99, rating: 4.5 },
    { id: 2, name: 'Shirt', category: 'clothing', price: 19.99, rating: 4.0 },
    { id: 3, name: 'Smartphone', category: 'electronics', price: 599.99, rating: 4.7 },
    { id: 4, name: 'Jeans', category: 'clothing', price: 49.99, rating: 4.2 },
    { id: 5, name: 'Tablet', category: 'electronics', price: 399.99, rating: 4.3 },
    { id: 6, name: 'Jacket', category: 'clothing', price: 89.99, rating: 4.6 },
    { id: 7, name: 'Blender', category: 'home', price: 29.99, rating: 4.1 },
    { id: 8, name: 'Sofa', category: 'home', price: 599.99, rating: 4.4 },
    { id: 9, name: 'Lipstick', category: 'beauty', price: 14.99, rating: 4.5 },
    { id: 10, name: 'Treadmill', category: 'sports', price: 799.99, rating: 4.8 }
  ];
  
  document.addEventListener('DOMContentLoaded', () => {
    displayProducts(products);
  
    document.getElementById('category-filter').addEventListener('change', filterProducts);
    document.getElementById('price-filter').addEventListener('change', filterProducts);
    document.getElementById('rating-filter').addEventListener('change', filterProducts);
  });
  
  function displayProducts(products) {
    const productList = document.getElementById('product-list');
    productList.innerHTML = '';
    products.forEach(product => {
      const productElement = document.createElement('div');
      productElement.className = 'product';
      productElement.innerHTML = `
        <img src="img" alt="${product.name}">
        <h2>${product.name}</h2>
        <p class="price">Price: $${product.price.toFixed(2)}</p>
        <p>Rating: ${'⭐'.repeat(Math.round(product.rating))}</p>
      `;
      productList.appendChild(productElement);
    });
  }
  
  function filterProducts() {
    const categoryFilter = document.getElementById('category-filter').value;
    const priceFilter = document.getElementById('price-filter').value;
    const ratingFilter = document.getElementById('rating-filter').value;
  
    let filteredProducts = products;
  
    if (categoryFilter !== 'all') {
      filteredProducts = filteredProducts.filter(product => product.category === categoryFilter);
    }
  
    if (priceFilter !== 'all') {
      if (priceFilter === 'low') {
        filteredProducts.sort((a, b) => a.price - b.price);
      } else {
        filteredProducts.sort((a, b) => b.price - a.price);
      }
    }
  
    if (ratingFilter !== 'all') {
      if (ratingFilter === 'low') {
        filteredProducts.sort((a, b) => a.rating - b.rating);
      } else {
        filteredProducts.sort((a, b) => b.rating - a.rating);
      }
    }
  
    displayProducts(filteredProducts);
  }
  