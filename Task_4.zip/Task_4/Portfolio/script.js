// Form validation
document.getElementById("contact-form").addEventListener("submit", function (e) {
    e.preventDefault();
    alert("Form submitted successfully!");
});

// Add class to navbar when scrolling up
window.onscroll = function () {
    var navbar = document.querySelector('.navbar');
    if (window.scrollY > 0) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
};


